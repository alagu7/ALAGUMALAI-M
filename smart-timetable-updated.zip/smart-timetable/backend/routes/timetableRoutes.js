const express = require('express');
const router = express.Router();
const Timetable = require('../models/Timetable');
const { protect } = require('../middleware/authMiddleware');

// All routes below require a valid logged-in user
router.use(protect);

const VALID_DAYS = ['Monday', 'Tuesday', 'Wednesday', 'Thursday', 'Friday', 'Saturday', 'Sunday'];
const VALID_TYPES = ['Lecture', 'Lab', 'Tutorial', 'Seminar', 'Other'];

// @route   GET /api/timetable
// @desc    Get all timetable entries for the logged-in user
// @access  Private
router.get('/', async (req, res) => {
  try {
    const entries = await Timetable.find({ userId: req.user._id }).sort({ day: 1, startTime: 1 });
    res.status(200).json({ success: true, count: entries.length, data: entries });
  } catch (error) {
    console.error('Get Timetable Error:', error.message);
    res.status(500).json({ success: false, message: 'Server error fetching timetable.' });
  }
});

// @route   GET /api/timetable/upcoming
// @desc    Get the next upcoming class for the logged-in user (based on current day/time)
// @access  Private
router.get('/upcoming', async (req, res) => {
  try {
    const entries = await Timetable.find({ userId: req.user._id });

    const now = new Date();
    const currentDayIndex = now.getDay(); // 0 = Sunday
    const currentMinutes = now.getHours() * 60 + now.getMinutes();
    const dayOrder = ['Sunday', 'Monday', 'Tuesday', 'Wednesday', 'Thursday', 'Friday', 'Saturday'];

    const toMinutes = (t) => {
      const [h, m] = t.split(':').map(Number);
      return h * 60 + m;
    };

    let best = null;
    let bestOffset = Infinity;

    entries.forEach((entry) => {
      const entryDayIndex = dayOrder.indexOf(entry.day);
      let dayDiff = entryDayIndex - currentDayIndex;
      if (dayDiff < 0) dayDiff += 7;

      let offset = dayDiff * 24 * 60 + (toMinutes(entry.startTime) - currentMinutes);
      if (dayDiff === 0 && toMinutes(entry.startTime) < currentMinutes) {
        offset += 7 * 24 * 60; // already passed today, push to next week
      }

      if (offset >= 0 && offset < bestOffset) {
        bestOffset = offset;
        best = entry;
      }
    });

    res.status(200).json({ success: true, data: best, minutesUntil: best ? bestOffset : null });
  } catch (error) {
    console.error('Upcoming Class Error:', error.message);
    res.status(500).json({ success: false, message: 'Server error fetching upcoming class.' });
  }
});

// @route   POST /api/timetable
// @desc    Create a new timetable entry for the logged-in user
// @access  Private
router.post('/', async (req, res) => {
  try {
    const { day, subject, faculty, startTime, endTime, room, type, section, notes } = req.body;

    if (!day || !subject || !startTime || !endTime) {
      return res.status(400).json({
        success: false,
        message: 'Day, subject, start time and end time are required.'
      });
    }

    if (!VALID_DAYS.includes(day)) {
      return res.status(400).json({ success: false, message: 'Invalid day value.' });
    }

    if (type && !VALID_TYPES.includes(type)) {
      return res.status(400).json({ success: false, message: 'Invalid class type value.' });
    }

    if (startTime >= endTime) {
      return res.status(400).json({ success: false, message: 'End time must be after start time.' });
    }

    const entry = await Timetable.create({
      userId: req.user._id,
      day,
      subject,
      faculty,
      startTime,
      endTime,
      room,
      type,
      section,
      notes
    });

    res.status(201).json({ success: true, message: 'Class added successfully.', data: entry });
  } catch (error) {
    console.error('Create Timetable Error:', error.message);
    res.status(500).json({ success: false, message: 'Server error creating timetable entry.' });
  }
});

// @route   PUT /api/timetable/:id
// @desc    Update a timetable entry (only if it belongs to the logged-in user)
// @access  Private
router.put('/:id', async (req, res) => {
  try {
    let entry = await Timetable.findById(req.params.id);

    if (!entry) {
      return res.status(404).json({ success: false, message: 'Timetable entry not found.' });
    }

    // Ownership check — never allow editing another user's data
    if (entry.userId.toString() !== req.user._id.toString()) {
      return res.status(403).json({ success: false, message: 'Not authorized to modify this entry.' });
    }

    const { day, subject, faculty, startTime, endTime, room, type, section, notes } = req.body;

    if (day && !VALID_DAYS.includes(day)) {
      return res.status(400).json({ success: false, message: 'Invalid day value.' });
    }
    if (type && !VALID_TYPES.includes(type)) {
      return res.status(400).json({ success: false, message: 'Invalid class type value.' });
    }

    entry.day = day ?? entry.day;
    entry.subject = subject ?? entry.subject;
    entry.faculty = faculty ?? entry.faculty;
    entry.startTime = startTime ?? entry.startTime;
    entry.endTime = endTime ?? entry.endTime;
    entry.room = room ?? entry.room;
    entry.type = type ?? entry.type;
    entry.section = section ?? entry.section;
    entry.notes = notes ?? entry.notes;

    if (entry.startTime >= entry.endTime) {
      return res.status(400).json({ success: false, message: 'End time must be after start time.' });
    }

    await entry.save();

    res.status(200).json({ success: true, message: 'Class updated successfully.', data: entry });
  } catch (error) {
    console.error('Update Timetable Error:', error.message);
    res.status(500).json({ success: false, message: 'Server error updating timetable entry.' });
  }
});

// @route   DELETE /api/timetable/:id
// @desc    Delete a timetable entry (only if it belongs to the logged-in user)
// @access  Private
router.delete('/:id', async (req, res) => {
  try {
    const entry = await Timetable.findById(req.params.id);

    if (!entry) {
      return res.status(404).json({ success: false, message: 'Timetable entry not found.' });
    }

    if (entry.userId.toString() !== req.user._id.toString()) {
      return res.status(403).json({ success: false, message: 'Not authorized to delete this entry.' });
    }

    await entry.deleteOne();

    res.status(200).json({ success: true, message: 'Class deleted successfully.' });
  } catch (error) {
    console.error('Delete Timetable Error:', error.message);
    res.status(500).json({ success: false, message: 'Server error deleting timetable entry.' });
  }
});

module.exports = router;
