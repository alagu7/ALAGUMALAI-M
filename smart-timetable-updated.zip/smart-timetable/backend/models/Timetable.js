const mongoose = require('mongoose');

const TimetableSchema = new mongoose.Schema({
  userId: {
    type: mongoose.Schema.Types.ObjectId,
    ref: 'User',
    required: true,
    index: true
  },
  day: {
    type: String,
    required: [true, 'Day is required'],
    enum: ['Monday', 'Tuesday', 'Wednesday', 'Thursday', 'Friday', 'Saturday', 'Sunday']
  },
  subject: {
    type: String,
    required: [true, 'Subject is required'],
    trim: true
  },
  faculty: {
    type: String,
    trim: true,
    default: ''
  },
  startTime: {
    type: String, // stored as "HH:MM" 24-hour format
    required: [true, 'Start time is required']
  },
  endTime: {
    type: String, // stored as "HH:MM" 24-hour format
    required: [true, 'End time is required']
  },
  room: {
    type: String,
    trim: true,
    default: ''
  },
  section: {
    type: String, // Class / Section (added for Timetable Creator feature)
    trim: true,
    default: ''
  },
  notes: {
    type: String, // Optional notes (added for Timetable Creator feature)
    trim: true,
    default: ''
  },
  type: {
    type: String,
    enum: ['Lecture', 'Lab', 'Tutorial', 'Seminar', 'Other'],
    default: 'Lecture'
  },
  createdAt: {
    type: Date,
    default: Date.now
  }
});

module.exports = mongoose.model('Timetable', TimetableSchema);
