/* ==========================================================================
   Smart Timetable — Frontend Application Logic
   ========================================================================== */

// Change this if your backend runs on a different host/port
const API_BASE_URL = 'http://localhost:5000/api';

const DAYS = ['Monday', 'Tuesday', 'Wednesday', 'Thursday', 'Friday', 'Saturday', 'Sunday'];

/* ---------------------------------------------------------------------- */
/*  Auth Storage Helpers                                                   */
/* ---------------------------------------------------------------------- */

const Auth = {
  getToken() {
    return localStorage.getItem('st_token');
  },
  getUser() {
    const raw = localStorage.getItem('st_user');
    return raw ? JSON.parse(raw) : null;
  },
  setSession(token, user) {
    localStorage.setItem('st_token', token);
    localStorage.setItem('st_user', JSON.stringify(user));
  },
  clearSession() {
    localStorage.removeItem('st_token');
    localStorage.removeItem('st_user');
  },
  isLoggedIn() {
    return !!this.getToken();
  },
  logout() {
    this.clearSession();
    window.location.href = 'login.html';
  }
};

// Redirect unauthenticated users away from protected pages
function requireAuth() {
  if (!Auth.isLoggedIn()) {
    window.location.href = 'login.html';
  }
}

// Redirect already-logged-in users away from login/register pages
function redirectIfLoggedIn() {
  if (Auth.isLoggedIn()) {
    window.location.href = 'dashboard.html';
  }
}

/* ---------------------------------------------------------------------- */
/*  API Helper                                                             */
/* ---------------------------------------------------------------------- */

async function apiRequest(endpoint, { method = 'GET', body = null, auth = false } = {}) {
  const headers = { 'Content-Type': 'application/json' };

  if (auth) {
    const token = Auth.getToken();
    if (token) headers['Authorization'] = `Bearer ${token}`;
  }

  const options = { method, headers };
  if (body) options.body = JSON.stringify(body);

  let response;
  try {
    response = await fetch(`${API_BASE_URL}${endpoint}`, options);
  } catch (networkErr) {
    throw new Error('Cannot reach the server. Please make sure the backend is running.');
  }

  let data;
  try {
    data = await response.json();
  } catch (e) {
    data = {};
  }

  if (response.status === 401 && auth) {
    // Token invalid/expired — force re-login
    Auth.clearSession();
    window.location.href = 'login.html';
    return;
  }

  if (!response.ok) {
    throw new Error(data.message || 'Something went wrong. Please try again.');
  }

  return data;
}

/* ---------------------------------------------------------------------- */
/*  UI Helpers                                                             */
/* ---------------------------------------------------------------------- */

function showAlert(elementId, message, type = 'danger') {
  const el = document.getElementById(elementId);
  if (!el) return;
  el.innerHTML = `
    <div class="alert alert-${type} alert-floating alert-dismissible fade show" role="alert">
      ${message}
      <button type="button" class="btn-close" data-bs-dismiss="alert" aria-label="Close"></button>
    </div>`;
}

function clearAlert(elementId) {
  const el = document.getElementById(elementId);
  if (el) el.innerHTML = '';
}

function setButtonLoading(btn, loading, loadingText = 'Please wait...') {
  if (!btn) return;
  if (loading) {
    btn.dataset.originalText = btn.innerHTML;
    btn.disabled = true;
    btn.innerHTML = `<span class="spinner-border spinner-border-sm me-2"></span>${loadingText}`;
  } else {
    btn.disabled = false;
    btn.innerHTML = btn.dataset.originalText || btn.innerHTML;
  }
}

function showToast(message, type = 'success') {
  let container = document.querySelector('.toast-container');
  if (!container) {
    container = document.createElement('div');
    container.className = 'toast-container position-fixed bottom-0 end-0 p-3';
    document.body.appendChild(container);
  }
  const toastEl = document.createElement('div');
  toastEl.className = `toast align-items-center text-bg-${type} border-0`;
  toastEl.setAttribute('role', 'alert');
  toastEl.innerHTML = `
    <div class="d-flex">
      <div class="toast-body">${message}</div>
      <button type="button" class="btn-close btn-close-white me-2 m-auto" data-bs-dismiss="toast"></button>
    </div>`;
  container.appendChild(toastEl);
  const toast = new bootstrap.Toast(toastEl, { delay: 4000 });
  toast.show();
  toastEl.addEventListener('hidden.bs.toast', () => toastEl.remove());
}

function formatTime12h(time24) {
  const [h, m] = time24.split(':').map(Number);
  const period = h >= 12 ? 'PM' : 'AM';
  const hour12 = h % 12 === 0 ? 12 : h % 12;
  return `${hour12}:${String(m).padStart(2, '0')} ${period}`;
}

/* ---------------------------------------------------------------------- */
/*  REGISTER PAGE                                                          */
/* ---------------------------------------------------------------------- */

function initRegisterPage() {
  redirectIfLoggedIn();

  const form = document.getElementById('registerForm');
  if (!form) return;

  form.addEventListener('submit', async (e) => {
    e.preventDefault();
    clearAlert('formAlert');

    const name = document.getElementById('name').value.trim();
    const email = document.getElementById('email').value.trim();
    const password = document.getElementById('password').value;
    const confirmPassword = document.getElementById('confirmPassword').value;
    const submitBtn = document.getElementById('registerBtn');

    // --- Client-side validation ---
    if (!name || !email || !password || !confirmPassword) {
      showAlert('formAlert', 'Please fill in all fields.');
      return;
    }
    const emailRegex = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
    if (!emailRegex.test(email)) {
      showAlert('formAlert', 'Please enter a valid email address.');
      return;
    }
    if (password.length < 8) {
      showAlert('formAlert', 'Password must be at least 8 characters long.');
      return;
    }
    if (password !== confirmPassword) {
      showAlert('formAlert', 'Passwords do not match.');
      return;
    }

    setButtonLoading(submitBtn, true, 'Creating account...');

    try {
      const data = await apiRequest('/auth/register', {
        method: 'POST',
        body: { name, email, password, confirmPassword }
      });
      showAlert('formAlert', 'Account created successfully! Redirecting to login...', 'success');
      setTimeout(() => (window.location.href = 'login.html'), 1200);
    } catch (err) {
      showAlert('formAlert', err.message);
    } finally {
      setButtonLoading(submitBtn, false);
    }
  });
}

/* ---------------------------------------------------------------------- */
/*  LOGIN PAGE                                                             */
/* ---------------------------------------------------------------------- */

function initLoginPage() {
  redirectIfLoggedIn();

  const form = document.getElementById('loginForm');
  if (!form) return;

  form.addEventListener('submit', async (e) => {
    e.preventDefault();
    clearAlert('formAlert');

    const email = document.getElementById('email').value.trim();
    const password = document.getElementById('password').value;
    const submitBtn = document.getElementById('loginBtn');

    if (!email || !password) {
      showAlert('formAlert', 'Please enter both email and password.');
      return;
    }

    setButtonLoading(submitBtn, true, 'Signing in...');

    try {
      const data = await apiRequest('/auth/login', {
        method: 'POST',
        body: { email, password }
      });
      Auth.setSession(data.token, data.user);
      window.location.href = 'dashboard.html';
    } catch (err) {
      showAlert('formAlert', err.message);
    } finally {
      setButtonLoading(submitBtn, false);
    }
  });
}

/* ---------------------------------------------------------------------- */
/*  DASHBOARD PAGE                                                         */
/* ---------------------------------------------------------------------- */

function initDashboardPage() {
  requireAuth();

  const user = Auth.getUser();
  const welcomeEl = document.getElementById('welcomeName');
  if (welcomeEl && user) welcomeEl.textContent = user.name;

  startClock();
  loadDashboardData();

  const logoutBtn = document.getElementById('logoutBtn');
  if (logoutBtn) logoutBtn.addEventListener('click', () => Auth.logout());
}

function startClock() {
  const clockEl = document.getElementById('liveClock');
  const dateEl = document.getElementById('liveDate');
  if (!clockEl && !dateEl) return;

  function tick() {
    const now = new Date();
    if (clockEl) {
      clockEl.textContent = now.toLocaleTimeString('en-US', {
        hour: '2-digit', minute: '2-digit', second: '2-digit', hour12: true
      });
    }
    if (dateEl) {
      dateEl.textContent = now.toLocaleDateString('en-US', {
        weekday: 'long', year: 'numeric', month: 'long', day: 'numeric'
      });
    }
  }
  tick();
  setInterval(tick, 1000);
}

async function loadDashboardData() {
  try {
    const [allRes, upcomingRes] = await Promise.all([
      apiRequest('/timetable', { auth: true }),
      apiRequest('/timetable/upcoming', { auth: true })
    ]);

    const entries = allRes.data || [];
    const today = DAYS[(new Date().getDay() + 6) % 7]; // convert JS Sunday=0 to Monday-first index
    const todayEntries = entries.filter((e) => e.day === today);

    // --- Stat cards ---
    setText('statTotalClasses', entries.length);
    setText('statTodayClasses', todayEntries.length);
    setText('statUniqueSubjects', new Set(entries.map((e) => e.subject)).size);

    // --- Upcoming class banner ---
    renderUpcomingBanner(upcomingRes.data, upcomingRes.minutesUntil);

    // --- Today's schedule list ---
    renderTodaySchedule(todayEntries);
  } catch (err) {
    console.error(err);
    showToast(err.message || 'Failed to load dashboard data.', 'danger');
  }
}

function setText(id, value) {
  const el = document.getElementById(id);
  if (el) el.textContent = value;
}

function renderUpcomingBanner(entry, minutesUntil) {
  const banner = document.getElementById('upcomingBanner');
  if (!banner) return;

  if (!entry) {
    banner.innerHTML = `
      <div class="d-flex align-items-center">
        <i class="fa-solid fa-circle-info text-secondary fs-3 me-3"></i>
        <div>
          <h6 class="mb-1">No upcoming classes</h6>
          <small class="text-muted">You haven't added any timetable entries yet.</small>
        </div>
      </div>`;
    return;
  }

  let whenText;
  if (minutesUntil < 60) {
    whenText = `in ${minutesUntil} minute${minutesUntil === 1 ? '' : 's'}`;
  } else if (minutesUntil < 24 * 60) {
    whenText = `in ${Math.floor(minutesUntil / 60)}h ${minutesUntil % 60}m`;
  } else {
    whenText = `on ${entry.day}`;
  }

  banner.innerHTML = `
    <div class="d-flex align-items-center justify-content-between flex-wrap gap-2">
      <div class="d-flex align-items-center">
        <i class="fa-solid fa-bell text-primary fs-3 me-3"></i>
        <div>
          <h6 class="mb-1">Next Class: ${escapeHtml(entry.subject)} <span class="badge badge-type-${entry.type} ms-1">${entry.type}</span></h6>
          <small class="text-muted">${entry.day}, ${formatTime12h(entry.startTime)} – ${formatTime12h(entry.endTime)} ${entry.room ? '· Room ' + escapeHtml(entry.room) : ''}</small>
        </div>
      </div>
      <span class="badge bg-primary rounded-pill px-3 py-2">Starts ${whenText}</span>
    </div>`;
}

function renderTodaySchedule(todayEntries) {
  const container = document.getElementById('todayScheduleList');
  if (!container) return;

  if (todayEntries.length === 0) {
    container.innerHTML = `
      <div class="empty-state">
        <i class="fa-regular fa-calendar-check"></i>
        <p class="mb-0">No classes scheduled for today. Enjoy your day! 🎉</p>
      </div>`;
    return;
  }

  const sorted = [...todayEntries].sort((a, b) => a.startTime.localeCompare(b.startTime));

  container.innerHTML = sorted.map((e) => `
    <div class="class-entry d-flex align-items-center justify-content-between flex-wrap gap-2">
      <div class="d-flex align-items-center">
        <div class="time-block me-3">${formatTime12h(e.startTime)}</div>
        <div>
          <div class="fw-semibold">${escapeHtml(e.subject)} <span class="badge badge-type-${e.type}">${e.type}</span></div>
          <small class="text-muted">${escapeHtml(e.faculty || 'N/A')} ${e.room ? '· Room ' + escapeHtml(e.room) : ''}</small>
        </div>
      </div>
      <span class="text-muted small">${formatTime12h(e.startTime)} – ${formatTime12h(e.endTime)}</span>
    </div>
  `).join('');
}

/* ---------------------------------------------------------------------- */
/*  TIMETABLE PAGE                                                         */
/* ---------------------------------------------------------------------- */

let currentEditId = null;
let cachedEntries = [];
let activeDay = 'Monday';

function initTimetablePage() {
  requireAuth();

  const user = Auth.getUser();
  const navUser = document.getElementById('navUserName');
  if (navUser && user) navUser.textContent = user.name;

  const logoutBtn = document.getElementById('logoutBtn');
  if (logoutBtn) logoutBtn.addEventListener('click', () => Auth.logout());

  buildDayTabs();
  loadTimetable();

  const classForm = document.getElementById('classForm');
  if (classForm) classForm.addEventListener('submit', handleClassFormSubmit);

  const addBtn = document.getElementById('openAddModalBtn');
  if (addBtn) addBtn.addEventListener('click', () => openClassModal());
}

function buildDayTabs() {
  const tabsContainer = document.getElementById('dayTabs');
  if (!tabsContainer) return;

  tabsContainer.innerHTML = DAYS.map((day) => `
    <button type="button" class="btn btn-outline-primary btn-sm day-tab-btn ${day === activeDay ? 'active' : ''}" data-day="${day}">
      ${day.substring(0, 3)}
    </button>
  `).join('');

  tabsContainer.querySelectorAll('.day-tab-btn').forEach((btn) => {
    btn.addEventListener('click', () => {
      activeDay = btn.dataset.day;
      tabsContainer.querySelectorAll('.day-tab-btn').forEach((b) => b.classList.remove('active'));
      btn.classList.add('active');
      renderDayEntries();
    });
  });
}

async function loadTimetable() {
  const listContainer = document.getElementById('classList');
  if (listContainer) {
    listContainer.innerHTML = `<div class="text-center py-5"><span class="spinner-border text-primary"></span></div>`;
  }
  try {
    const res = await apiRequest('/timetable', { auth: true });
    cachedEntries = res.data || [];
    renderDayEntries();
  } catch (err) {
    showToast(err.message || 'Failed to load timetable.', 'danger');
  }
}

function renderDayEntries() {
  const listContainer = document.getElementById('classList');
  if (!listContainer) return;

  const entries = cachedEntries
    .filter((e) => e.day === activeDay)
    .sort((a, b) => a.startTime.localeCompare(b.startTime));

  if (entries.length === 0) {
    listContainer.innerHTML = `
      <div class="empty-state">
        <i class="fa-regular fa-calendar-plus"></i>
        <p class="mb-2">No classes scheduled for ${activeDay}.</p>
        <button class="btn btn-primary btn-sm" onclick="openClassModal()">
          <i class="fa-solid fa-plus me-1"></i> Add Class
        </button>
      </div>`;
    return;
  }

  listContainer.innerHTML = entries.map((e) => `
    <div class="class-entry d-flex align-items-center justify-content-between flex-wrap gap-2">
      <div class="d-flex align-items-center">
        <div class="time-block me-3">${formatTime12h(e.startTime)}<br><small class="text-muted fw-normal">${formatTime12h(e.endTime)}</small></div>
        <div>
          <div class="fw-semibold">${escapeHtml(e.subject)} <span class="badge badge-type-${e.type}">${e.type}</span></div>
          <small class="text-muted d-block"><i class="fa-solid fa-user-tie me-1"></i>${escapeHtml(e.faculty || 'N/A')}</small>
          <small class="text-muted"><i class="fa-solid fa-location-dot me-1"></i>${escapeHtml(e.room || 'N/A')}</small>
        </div>
      </div>
      <div class="btn-group">
        <button class="btn btn-sm btn-outline-secondary" onclick="openClassModal('${e._id}')"><i class="fa-solid fa-pen"></i></button>
        <button class="btn btn-sm btn-outline-danger" onclick="deleteClass('${e._id}')"><i class="fa-solid fa-trash"></i></button>
      </div>
    </div>
  `).join('');
}

function openClassModal(id = null) {
  currentEditId = id;
  const modalTitle = document.getElementById('classModalTitle');
  const form = document.getElementById('classForm');
  form.reset();
  clearAlert('modalAlert');

  document.getElementById('day').value = activeDay;

  if (id) {
    const entry = cachedEntries.find((e) => e._id === id);
    if (entry) {
      modalTitle.textContent = 'Edit Class';
      document.getElementById('day').value = entry.day;
      document.getElementById('subject').value = entry.subject;
      document.getElementById('faculty').value = entry.faculty || '';
      document.getElementById('startTime').value = entry.startTime;
      document.getElementById('endTime').value = entry.endTime;
      document.getElementById('room').value = entry.room || '';
      document.getElementById('type').value = entry.type;
    }
  } else {
    modalTitle.textContent = 'Add Class';
  }

  const modal = new bootstrap.Modal(document.getElementById('classModal'));
  modal.show();
}

async function handleClassFormSubmit(e) {
  e.preventDefault();
  clearAlert('modalAlert');

  const payload = {
    day: document.getElementById('day').value,
    subject: document.getElementById('subject').value.trim(),
    faculty: document.getElementById('faculty').value.trim(),
    startTime: document.getElementById('startTime').value,
    endTime: document.getElementById('endTime').value,
    room: document.getElementById('room').value.trim(),
    type: document.getElementById('type').value
  };

  if (!payload.day || !payload.subject || !payload.startTime || !payload.endTime) {
    showAlert('modalAlert', 'Please fill in all required fields.');
    return;
  }
  if (payload.startTime >= payload.endTime) {
    showAlert('modalAlert', 'End time must be after start time.');
    return;
  }

  const submitBtn = document.getElementById('saveClassBtn');
  setButtonLoading(submitBtn, true, 'Saving...');

  try {
    if (currentEditId) {
      await apiRequest(`/timetable/${currentEditId}`, { method: 'PUT', body: payload, auth: true });
      showToast('Class updated successfully.');
    } else {
      await apiRequest('/timetable', { method: 'POST', body: payload, auth: true });
      showToast('Class added successfully.');
    }
    bootstrap.Modal.getInstance(document.getElementById('classModal')).hide();
    activeDay = payload.day;
    buildDayTabs();
    await loadTimetable();
  } catch (err) {
    showAlert('modalAlert', err.message);
  } finally {
    setButtonLoading(submitBtn, false);
  }
}

async function deleteClass(id) {
  if (!confirm('Are you sure you want to delete this class?')) return;
  try {
    await apiRequest(`/timetable/${id}`, { method: 'DELETE', auth: true });
    showToast('Class deleted.');
    await loadTimetable();
  } catch (err) {
    showToast(err.message || 'Failed to delete class.', 'danger');
  }
}

function escapeHtml(str) {
  if (!str) return '';
  return str
    .replace(/&/g, '&amp;')
    .replace(/</g, '&lt;')
    .replace(/>/g, '&gt;')
    .replace(/"/g, '&quot;');
}

/* ---------------------------------------------------------------------- */
/*  TIMETABLE CREATOR PAGE (weekly grid view)                              */
/*  Uses the same /api/timetable backend as the "My Timetable" page,       */
/*  plus the optional section/notes fields.                                */
/* ---------------------------------------------------------------------- */

const TC_DAYS = ['Monday', 'Tuesday', 'Wednesday', 'Thursday', 'Friday', 'Saturday', 'Sunday'];

let tcCachedEntries = [];
let tcCurrentEditId = null;

function initTimetableCreatorPage() {
  requireAuth();

  const user = Auth.getUser();
  const navUser = document.getElementById('navUserName');
  if (navUser && user) navUser.textContent = user.name;

  const logoutBtn = document.getElementById('logoutBtn');
  if (logoutBtn) logoutBtn.addEventListener('click', () => Auth.logout());

  const addBtn = document.getElementById('tcOpenAddModalBtn');
  if (addBtn) addBtn.addEventListener('click', () => tcOpenClassModal());

  const clearBtn = document.getElementById('tcClearAllBtn');
  if (clearBtn) clearBtn.addEventListener('click', tcClearAll);

  const form = document.getElementById('tcClassForm');
  if (form) form.addEventListener('submit', tcHandleFormSubmit);

  tcBuildGridHead();
  tcLoadEntries();
}

function tcBuildGridHead() {
  const head = document.getElementById('tcGridHead');
  if (!head) return;
  head.innerHTML = `<th>Time</th>` + TC_DAYS.map((d) => `<th>${d}</th>`).join('');
}

async function tcLoadEntries() {
  const body = document.getElementById('tcGridBody');
  if (body) {
    body.innerHTML = `<tr><td colspan="8" class="text-center py-5"><span class="spinner-border text-primary"></span></td></tr>`;
  }
  try {
    const res = await apiRequest('/timetable', { auth: true });
    tcCachedEntries = res.data || [];
    tcRenderGrid();
  } catch (err) {
    showToast(err.message || 'Failed to load timetable.', 'danger');
  }
}

function tcRenderGrid() {
  const body = document.getElementById('tcGridBody');
  if (!body) return;

  if (tcCachedEntries.length === 0) {
    body.innerHTML = `
      <tr>
        <td colspan="8">
          <div class="empty-state">
            <i class="fa-regular fa-calendar-plus"></i>
            <p class="mb-2">Your weekly timetable is empty.</p>
            <button class="btn btn-primary btn-sm" onclick="tcOpenClassModal()">
              <i class="fa-solid fa-plus me-1"></i> Add Class
            </button>
          </div>
        </td>
      </tr>`;
    return;
  }

  const timeSlots = [...new Set(tcCachedEntries.map((e) => e.startTime))].sort();

  body.innerHTML = timeSlots.map((slot) => {
    const rowEntries = tcCachedEntries.filter((e) => e.startTime === slot);
    const endTime = rowEntries[0] ? rowEntries[0].endTime : '';

    const cells = TC_DAYS.map((day) => {
      const dayEntries = rowEntries.filter((e) => e.day === day);
      if (dayEntries.length === 0) {
        return `<td class="tc-empty-cell">—</td>`;
      }
      return `<td>${dayEntries.map((e) => tcClassBlockHtml(e)).join('')}</td>`;
    }).join('');

    return `
      <tr>
        <td class="tc-time-cell">${formatTime12h(slot)}${endTime ? ' – ' + formatTime12h(endTime) : ''}</td>
        ${cells}
      </tr>`;
  }).join('');
}

function tcClassBlockHtml(e) {
  return `
    <div class="tc-class-block">
      <div class="tc-subject">${escapeHtml(e.subject)}</div>
      ${e.faculty ? `<small><i class="fa-solid fa-user-tie me-1"></i>${escapeHtml(e.faculty)}</small>` : ''}
      ${e.room ? `<small><i class="fa-solid fa-location-dot me-1"></i>Room ${escapeHtml(e.room)}</small>` : ''}
      ${e.section ? `<small><i class="fa-solid fa-users me-1"></i>${escapeHtml(e.section)}</small>` : ''}
      ${e.notes ? `<small><i class="fa-solid fa-note-sticky me-1"></i>${escapeHtml(e.notes)}</small>` : ''}
      <div class="tc-actions btn-group">
        <button class="btn btn-sm btn-outline-secondary" onclick="tcOpenClassModal('${e._id}')"><i class="fa-solid fa-pen"></i></button>
        <button class="btn btn-sm btn-outline-danger" onclick="tcDeleteClass('${e._id}')"><i class="fa-solid fa-trash"></i></button>
      </div>
    </div>`;
}

function tcOpenClassModal(id = null) {
  tcCurrentEditId = id;
  const modalTitle = document.getElementById('tcClassModalTitle');
  const form = document.getElementById('tcClassForm');
  form.reset();
  clearAlert('tcModalAlert');

  if (id) {
    const entry = tcCachedEntries.find((e) => e._id === id);
    if (entry) {
      modalTitle.textContent = 'Edit Class';
      document.getElementById('tcDay').value = entry.day;
      document.getElementById('tcSubject').value = entry.subject;
      document.getElementById('tcFaculty').value = entry.faculty || '';
      document.getElementById('tcStartTime').value = entry.startTime;
      document.getElementById('tcEndTime').value = entry.endTime;
      document.getElementById('tcRoom').value = entry.room || '';
      document.getElementById('tcSection').value = entry.section || '';
      document.getElementById('tcNotes').value = entry.notes || '';
    }
  } else {
    modalTitle.textContent = 'Add Class';
  }

  const modal = new bootstrap.Modal(document.getElementById('tcClassModal'));
  modal.show();
}

async function tcHandleFormSubmit(e) {
  e.preventDefault();
  clearAlert('tcModalAlert');

  const payload = {
    day: document.getElementById('tcDay').value,
    subject: document.getElementById('tcSubject').value.trim(),
    faculty: document.getElementById('tcFaculty').value.trim(),
    startTime: document.getElementById('tcStartTime').value,
    endTime: document.getElementById('tcEndTime').value,
    room: document.getElementById('tcRoom').value.trim(),
    section: document.getElementById('tcSection').value.trim(),
    notes: document.getElementById('tcNotes').value.trim()
  };

  if (!payload.day || !payload.subject || !payload.startTime || !payload.endTime) {
    showAlert('tcModalAlert', 'Please fill in all required fields.');
    return;
  }
  if (payload.startTime >= payload.endTime) {
    showAlert('tcModalAlert', 'End time must be after start time.');
    return;
  }

  const submitBtn = document.getElementById('tcSaveClassBtn');
  setButtonLoading(submitBtn, true, 'Saving...');

  try {
    if (tcCurrentEditId) {
      await apiRequest(`/timetable/${tcCurrentEditId}`, { method: 'PUT', body: payload, auth: true });
      showToast('Class updated successfully.');
    } else {
      await apiRequest('/timetable', { method: 'POST', body: payload, auth: true });
      showToast('Class added successfully.');
    }
    bootstrap.Modal.getInstance(document.getElementById('tcClassModal')).hide();
    await tcLoadEntries();
  } catch (err) {
    showAlert('tcModalAlert', err.message);
  } finally {
    setButtonLoading(submitBtn, false);
  }
}

async function tcDeleteClass(id) {
  if (!confirm('Are you sure you want to delete this class?')) return;
  try {
    await apiRequest(`/timetable/${id}`, { method: 'DELETE', auth: true });
    showToast('Class deleted.');
    await tcLoadEntries();
  } catch (err) {
    showToast(err.message || 'Failed to delete class.', 'danger');
  }
}

async function tcClearAll() {
  if (tcCachedEntries.length === 0) {
    showToast('Your timetable is already empty.', 'danger');
    return;
  }
  if (!confirm('This will delete ALL classes in your timetable. Continue?')) return;

  const clearBtn = document.getElementById('tcClearAllBtn');
  setButtonLoading(clearBtn, true, 'Clearing...');

  try {
    await Promise.all(tcCachedEntries.map((e) => apiRequest(`/timetable/${e._id}`, { method: 'DELETE', auth: true })));
    showToast('Timetable cleared.');
    await tcLoadEntries();
  } catch (err) {
    showToast(err.message || 'Failed to clear timetable.', 'danger');
  } finally {
    setButtonLoading(clearBtn, false);
  }
}

/* ---------------------------------------------------------------------- */
/*  Page Router — runs the correct init function based on body[data-page]  */
/* ---------------------------------------------------------------------- */

document.addEventListener('DOMContentLoaded', () => {
  const page = document.body.dataset.page;
  switch (page) {
    case 'register':
      initRegisterPage();
      break;
    case 'login':
      initLoginPage();
      break;
    case 'dashboard':
      initDashboardPage();
      break;
    case 'timetable':
      initTimetablePage();
      break;
    case 'timetable-creator':
      initTimetableCreatorPage();
      break;
    default:
      break;
  }
});
