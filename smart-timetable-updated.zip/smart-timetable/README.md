# 📅 Smart Timetable — College Class Schedule Manager

A full-stack web application that lets college students register, log in, and manage a
personal weekly class timetable with a live dashboard and upcoming-class notifications.

## 🧱 Tech Stack

**Frontend:** HTML5, CSS3, Vanilla JavaScript, Bootstrap 5, Font Awesome (no frameworks)
**Backend:** Node.js, Express.js, MongoDB, Mongoose, JWT, bcryptjs, dotenv, CORS

## 📂 Project Structure

```
smart-timetable/
│
├── frontend/
│   ├── index.html        # Landing page
│   ├── login.html        # Login page
│   ├── register.html     # Registration page
│   ├── dashboard.html    # Student dashboard (protected)
│   ├── timetable.html    # Timetable manager (protected)
│   ├── style.css
│   └── script.js
│
├── backend/
│   ├── server.js
│   ├── package.json
│   ├── .env
│   ├── config/db.js
│   ├── models/User.js
│   ├── models/Timetable.js
│   ├── routes/authRoutes.js
│   ├── routes/timetableRoutes.js
│   └── middleware/authMiddleware.js
│
└── README.md
```

## 🚀 Getting Started

### 1. Prerequisites
- [Node.js](https://nodejs.org/) v18+
- MongoDB running locally, **or** a free [MongoDB Atlas](https://www.mongodb.com/atlas) cluster

### 2. Backend Setup

```bash
cd backend
npm install
```

Open `.env` and set your own values:

```
PORT=5000
MONGO_URI=mongodb://127.0.0.1:27017/smart-timetable
JWT_SECRET=change_this_to_a_long_random_secret_key
JWT_EXPIRE=7d
CLIENT_ORIGIN=http://127.0.0.1:5500
```

Start the server:

```bash
npm start
# or, for auto-reload during development:
npm run dev
```

The API will run at `http://localhost:5000`.

### 3. Frontend Setup

The frontend is plain static HTML/CSS/JS — no build step needed.

- Open `frontend/index.html` directly in your browser, **or**
- Serve it with a lightweight static server, e.g. the VS Code "Live Server" extension
  (defaults to `http://127.0.0.1:5500`).

If your backend runs on a different host/port, update `API_BASE_URL` at the top of
`frontend/script.js`:

```js
const API_BASE_URL = 'http://localhost:5000/api';
```

### 4. Using the App

1. Open `index.html` → click **Get Started** to register a new account.
2. Log in with your credentials — you'll receive a JWT stored in `localStorage`.
3. You're redirected to the **Dashboard**, showing a welcome message, live clock,
   stats, and your next upcoming class.
4. Go to **My Timetable** to add, edit, or delete classes for any day of the week.
5. Click **Logout** to clear your session. Visiting `dashboard.html` or
   `timetable.html` without a valid session redirects you back to `login.html`.

## 🔐 Security Notes

- Passwords are hashed with **bcryptjs** before being stored — never in plain text.
- Protected API routes require a valid JWT sent as `Authorization: Bearer <token>`.
- Every timetable query is scoped to `req.user._id`, so a user can only ever see,
  edit, or delete **their own** records — verified both in queries and via an
  explicit ownership check before update/delete.
- Emails are enforced unique at the database level (Mongoose `unique: true` index).

## 📡 API Reference

| Method | Endpoint                  | Access  | Description                          |
|--------|----------------------------|---------|---------------------------------------|
| POST   | `/api/auth/register`       | Public  | Register a new user                   |
| POST   | `/api/auth/login`          | Public  | Log in, returns JWT                   |
| GET    | `/api/auth/me`             | Private | Get current user's profile            |
| GET    | `/api/timetable`           | Private | Get all of the user's classes         |
| GET    | `/api/timetable/upcoming`  | Private | Get the next upcoming class           |
| POST   | `/api/timetable`           | Private | Add a new class                       |
| PUT    | `/api/timetable/:id`       | Private | Update a class (owner only)           |
| DELETE | `/api/timetable/:id`       | Private | Delete a class (owner only)           |

## 🛠 Troubleshooting

- **"Cannot reach the server"** → make sure the backend is running on the port set
  in `API_BASE_URL`.
- **CORS errors** → the backend uses `cors()` with defaults (allow-all) for easy
  local development; restrict it to `CLIENT_ORIGIN` before deploying to production.
- **MongoDB connection errors** → double-check `MONGO_URI` in `backend/.env`.
